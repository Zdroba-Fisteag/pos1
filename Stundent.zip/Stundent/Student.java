public class Student {
    private String name;
    private double kg;
    private int cm;
    private char gender;
    public static double x;
    
    //setter für name
    public void setName(String name) {
        this.name = name;
    }
    // Try this yourself
    /*public double bmi() {
        this.kg = kg;
        this.cm = cm;
        return kg/((cm*cm)*(100*100));
    }*/
    public void setKg (double kilogramm) {
        this.kg = kilogramm;
    }
    public void setCm (int cm) {
        this.cm = cm;
    }
    public void setGender (char gen) {
        this.gender = gen;
    }
    //Constructor
    public Student (String name, double kg, int cm, char gender) {
        this.setName(name);
        this.setKg(kg);
        this.setCm(cm);
        this.setGender(gender);
    }
    public double bmi() {
        x = this.kg/((this.cm/100.0)*(this.cm/100.0));
        return x;
    }
    public String mannOderFrau () {
        if (this.gender == 'm') {
            return "männlich";
        } else if (this.gender == 'w') {
            return "weiblich";
        } else {
            return "N/A";
        }
    }
    public String printStudent() {
        return "Name: " + this.name + " (" + this.mannOderFrau() + ")";
    }
    public String fatOrNot() { //Checkt, ob du übergewichtig bist oder nicht
        if(this.gender == 'w') {
            if (bmi() < 19) {
                return "Du bist untergewichtig!!!";
            } else if (bmi() >= 19 && bmi() < 24) {
                return "Standard";
            } else if (bmi() >= 24 && bmi() < 29) {
                return "Ein bisschen weniger Essen wäre gut.";
            } else if (bmi() > 29) {
                return "Wie viele Mc's hast du bisher gesammelt? :)";
            }
        } else if (this.gender == 'm') {
            if (bmi() < 20) {
                return "Du bist untergewichtig!!!";
            } else if (bmi() >= 20 && bmi() < 25) {
                return "Standard";
            } else if (bmi() >= 25 && bmi() < 30) {
                return "Ein bisschen weniger Essen wäre gut.";
            } else if (bmi() > 30) {
                return "Wie viele Mc's hast du bisher gesammelt? :)";
            }
        } else {
            return "Bitte geben Sie ein valides Geschlecht ein!";
        }
        return "Program works"; // Diesen return muss ich machen, ansonsten compilet es nicht
    }
}